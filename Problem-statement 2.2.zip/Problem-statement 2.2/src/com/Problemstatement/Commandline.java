package com.Problemstatement;

import java.util.*;

public class Commandline {
	public static void main(String[] args) {
		int n=15, num1,num2;
		System.out.println("Given the value of num 1");
		System.out.println("Given the value of num 2");
		
		Scanner sc=new Scanner(System.in);
		num1 =sc.nextInt();
		num2 =sc.nextInt();
		
		System.out.println("Series "+n+"numbers: ");
		for (int i=1; i<=n; i++)
		{
			System.out.println(num1+" ");
			int Sumofprevtwo = num1+num2;
			num1=num2;
			num2=Sumofprevtwo;
		}
	}

}

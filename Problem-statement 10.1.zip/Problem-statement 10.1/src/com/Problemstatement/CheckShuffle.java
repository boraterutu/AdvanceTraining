package com.Problemstatement;

import java.util.Scanner;
import java.util.Arrays;

public class CheckShuffle {
	
	  static boolean checkLength(String first, String second, String third) {
	    if (first.length() + second.length() != third.length()) {
	      return false;
	    }
	    else {
	      return true;
	    }
	  }
	  static String sortString(String str) {
	  
	    char[] charArray = str.toCharArray();
	    Arrays.sort(charArray);
	    str = String.valueOf(charArray);

	    return str;
	  }

	  static boolean shuffleCheck(String first, String second, String third) {
	    
	   
	    first = sortString(first);
	    second = sortString(second);
	    third = sortString(third);

	    
	    int i = 0, j = 0, k = 0;

	    while (k !=third.length()) {

	      if (i < first.length() && first.charAt(i) == third.charAt(k))
	        i++;

	      else if (j < second.length() && second.charAt(j) ==third.charAt(k))
	        j++;

	      else {
	        return false;
	      }

	      k++;
	    }

	    if(i < first.length() || j < second.length()) {
	      return false;
	    }

	    return true;
	  }

	  public static void main(String[] args) 
	  {
	    Scanner sc =new Scanner(System.in);
	    System.out.println("Enter the first string :");
	    String first = sc.next();
	    System.out.println("Enter the second string :");
	    String second = sc.next();
	    System.out.println("Enter the Third string :");
	    String third = sc.next();

	   
	      if (checkLength(first, second, third) == true && shuffleCheck(first, second, third) == true) 
	      {
	        System.out.println("True : Third string is valid shuffle of first and second string.");
	      }
	      
	      else 
	      {
		    System.out.println("False : Third string is NOT valid shuffle of first and second string.");
	      }
	      
	    }
	  
}